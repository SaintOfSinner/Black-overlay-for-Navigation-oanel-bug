package com.example.bottomstrip

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("strip", Context.MODE_PRIVATE)

    fun height(c: Context): Int = sp(c).getInt("height", 30)
    fun setHeight(c: Context, v: Int) = sp(c).edit().putInt("height", v).apply()

    fun enabled(c: Context): Boolean = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()
}
