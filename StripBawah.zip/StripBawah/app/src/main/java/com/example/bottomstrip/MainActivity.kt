package com.example.bottomstrip

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var sw: Switch
    private lateinit var seek: SeekBar
    private lateinit var label: TextView
    private var updating = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "Strip hitam di bawah layar"
            textSize = 20f
        })

        sw = Switch(this).apply { text = "ON / OFF" ; textSize = 18f }
        root.addView(sw)

        label = TextView(this).apply { textSize = 18f }
        root.addView(label)

        seek = SeekBar(this).apply { max = 119 } // 1..120 px
        root.addView(seek)

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val minus = Button(this).apply { text = "-1 px" }
        val plus = Button(this).apply { text = "+1 px" }
        row.addView(minus)
        row.addView(plus)
        root.addView(row)

        setContentView(root)

        seek.progress = Prefs.height(this) - 1
        refreshLabel()
        sw.isChecked = Prefs.enabled(this)

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                Prefs.setHeight(this@MainActivity, p + 1)
                refreshLabel()
                applyState()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        minus.setOnClickListener { seek.progress = (seek.progress - 1).coerceAtLeast(0) }
        plus.setOnClickListener { seek.progress = (seek.progress + 1).coerceAtMost(seek.max) }

        sw.setOnCheckedChangeListener { _, checked ->
            if (updating) return@setOnCheckedChangeListener
            if (checked && !Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Izinkan 'Tampil di atas aplikasi lain', lalu kembali", Toast.LENGTH_LONG).show()
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
                updating = true
                sw.isChecked = false
                updating = false
                return@setOnCheckedChangeListener
            }
            Prefs.setEnabled(this, checked)
            applyState()
        }
    }

    private fun refreshLabel() {
        label.text = "Tinggi: ${Prefs.height(this)} px"
    }

    private fun applyState() {
        val svc = Intent(this, OverlayService::class.java)
        if (Prefs.enabled(this) && Settings.canDrawOverlays(this)) {
            startForegroundService(svc)
        } else {
            stopService(svc)
        }
    }
}
